import { Train } from "./models/Train";


if (require.main === module) {
  new Train().run();
}